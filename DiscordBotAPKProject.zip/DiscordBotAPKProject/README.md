# Farsian Community Bot — Android APK project

This project ports the supplied Node.js/discord.js bot to Python/discord.py so it can be packaged as a real Android APK without Android Studio on the user's PC.

## Build the APK without Android Studio

The included GitHub Actions workflow builds the APK in GitHub's Linux runner, so the local Android SDK is not required.

1. Create a private GitHub repository.
2. Upload the contents of this folder.
3. Open **Actions** and run **Build Android APK**.
4. When it finishes, open the workflow run and download the artifact **farsian-community-bot-apk**.
5. Extract the ZIP and install the APK on Android.

The APK asks for the bot token at runtime and does not write the token to the project files.

## Commands ported

- `/testping`
- `/nameserver`
- `/ban`
- `/kick`
- `/timeout`
- `/clear`

It also updates the streaming presence every 5 minutes and registers the slash commands for each guild.

### Important
Android can restrict background apps. For long-running bot operation, keep the app running and disable battery optimization for it. A future version can add a native foreground service if required.
